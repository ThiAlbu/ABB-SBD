from registro import Registro
from abb import ABB

# EDL = "arquivo de registros"
edl = []

# Cria a ABB já associada à EDL
abb = ABB(edl)


# 1. Inserir vários registros de uma vez
def inserir_varios():
    registros = [
        Registro("33333333333", "Carla", "1998-03-03"),
        Registro("11111111111", "Ana", "2000-01-01"),
        Registro("22222222222", "Bruno", "1999-02-02"),
        Registro("44444444444", "Davi", "2001-04-04")
    ]
    abb.inserir(registros)
    print("Registros inseridos com sucesso.")

# 2. Buscar um registro por CPF
def buscar_por_cpf(cpf):
    no = abb.buscar(cpf)
    if no:
        reg = edl[no.posicao]
        if reg.deletado:
            print(f"Registro com CPF {cpf} foi deletado.")
        else:
            print(f"Registro encontrado: {reg}")
    else:
        print(f"CPF {cpf} não encontrado.")

# 3. Remover um registro por CPF
def remover_por_cpf(cpf):
    abb.remover_registro(cpf)

# 4. Exibir todos os registros ordenados por CPF
def exibir_registros_ordenados():
    print("\nRegistros ordenados por CPF:")
    for pos in abb.em_ordem():
        reg = edl[pos]
        if not reg.deletado:
            print(reg)

"""
inserir_registro(abb, "11111111111", "Ana", "2000-01-01")
inserir_registro(abb, "22222222222", "Bruno", "1999-02-02")
inserir_registro(abb, "33333333333", "Carla", "1998-03-03")
"""
registros = [
    Registro("33333333333", "Carla", "1998-03-03"),
    Registro("11111111111", "Ana", "2000-01-01"),
    Registro("22222222222", "Bruno", "1999-02-02"),
    Registro("44444444444", "Davi", "2001-04-04")
]

abb.inserir(registros)

print("\nBusca:")
buscar_por_cpf( "22222222222")

print("\nRemoção:")
remover_por_cpf( "22222222222")

print("\nBusca após remoção:")
buscar_por_cpf( "22222222222")

print("\nRegistros ordenados:")
exibir_registros_ordenados()
