class NoABB:
    def __init__(self, chave, posicao):
        self.chave = chave  # CPF como string
        self.posicao = posicao  # índice na EDL
        self.esq = None
        self.dir = None
