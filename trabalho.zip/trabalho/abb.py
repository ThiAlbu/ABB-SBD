from no_abb import NoABB
from registro import Registro

class ABB:
    def __init__(self, edl, registros=None):
        self.raiz = None
        self.edl = edl
        if registros:
            self.inserir(registros)

    def inserir(self, registro_ou_lista):
        if isinstance(registro_ou_lista, list):
            for reg in registro_ou_lista:
                self._inserir_registro(reg)
        elif isinstance(registro_ou_lista, Registro):
            self._inserir_registro(registro_ou_lista)
        else:
            raise TypeError("Esperado Registro ou lista de Registro")

    def _inserir_registro(self, registro):
        posicao = len(self.edl)
        self.edl.append(registro)
        self.raiz = self._inserir(self.raiz, registro.cpf, posicao)

    def _inserir(self, no, chave, posicao):
        if no is None:
            return NoABB(chave, posicao)
        if chave < no.chave:
            no.esq = self._inserir(no.esq, chave, posicao)
        elif chave > no.chave:
            no.dir = self._inserir(no.dir, chave, posicao)
        return no

    def buscar(self, chave):
        return self._buscar(self.raiz, chave)

    def _buscar(self, no, chave):
        if no is None:
            return None
        if chave == no.chave:
            return no
        elif chave < no.chave:
            return self._buscar(no.esq, chave)
        else:
            return self._buscar(no.dir, chave)

    def remover(self, chave):
        self.raiz = self._remover(self.raiz, chave)

    def _remover(self, no, chave):
        if no is None:
            return None
        if chave < no.chave:
            no.esq = self._remover(no.esq, chave)
        elif chave > no.chave:
            no.dir = self._remover(no.dir, chave)
        else:
            if no.esq is None:
                return no.dir
            elif no.dir is None:
                return no.esq
            sucessor = self._min(no.dir)
            no.chave, no.posicao = sucessor.chave, sucessor.posicao
            no.dir = self._remover(no.dir, sucessor.chave)
        return no

    def remover_registro(self, cpf):
        no = self.buscar(cpf)
        if no:
            self.edl[no.posicao].marcar_como_deletado()
            self.remover(cpf)
            print(f"Registro com CPF {cpf} foi removido.")
        else:
            print(f"CPF {cpf} não encontrado.")

    def _min(self, no):
        while no.esq:
            no = no.esq
        return no

    def em_ordem(self):
        resultado = []
        self._em_ordem(self.raiz, resultado)
        return resultado

    def _em_ordem(self, no, resultado):
        if no:
            self._em_ordem(no.esq, resultado)
            resultado.append(no.posicao)
            self._em_ordem(no.dir, resultado)
