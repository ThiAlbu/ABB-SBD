class Registro:
    def __init__(self, cpf, nome, data_nasc):
        self.cpf = cpf  # string
        self.nome = nome  # string
        self.data_nasc = data_nasc  # string
        self.deletado = False

    def __lt__(self, outro):
        return self.cpf < outro.cpf

    def __eq__(self, outro):
        return self.cpf == outro.cpf

    def __str__(self):
        return f'CPF: {self.cpf}, Nome: {self.nome}, Data: {self.data_nasc}'

    def marcar_como_deletado(self):
        self.deletado = True
